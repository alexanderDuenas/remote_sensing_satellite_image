import time
import logging
import uuid
import base64
import json
import socket
import random
import requests
import datetime
import jwt
from threading import Thread
from beaker.cache import CacheManager
from beaker.util import parse_cache_config_options

JWT_ALGORITHM = 'HS512'
JWT_PAYLOAD = {'sub': 'admin', 'auth': 'ROLE_ADMIN,ROLE_USER'}

CACHE_OPTS = {
    'cache.type': 'memory',
}
_cache = CacheManager(**parse_cache_config_options(CACHE_OPTS))

logger = logging.getLogger('eureka')

def get_timestamp():
    return int(time.time())

class EurekaClientError(Exception):
    def __init__(self, status_code, body):
        super().__init__("Error on eureka server request: {}".format(
            status_code))
        self.status_code = status_code
        self.body = body

class ServiceError(Exception):
    def __init__(self, status_code, body):
        super().__init__("Error on service request: {}".format(
            status_code))
        self.status_code = status_code
        self.body = body

class SpringCloudConfigServer:
    """
    SpringCloudConfigServer is used to get configurations from a Spring
    Cloud Config server for given application and profile.

    :param server_url: url of the Spring Config Server
    :param application: application on the config server
    :param profile: profile on the config server
    :param credentials: user/password tuple such as ("admin","admin")
    :param auth_token: Bearer token (if credentials are not provided)
    """
    def __init__(self,
                 server_url,
                 appplication,
                 profile,
                 credentials=(),
                 auth_token=None):
        self.server_url = server_url
        self.application = appplication
        self.profile = profile
        self.credentials = ":".join(list(credentials))
        self.auth_token = auth_token
        self.config = None
        self.config_fields = None

    def _make_headers(self):
        headers = {'accept': 'application/json'}
        if self.credentials:
            basic_auth = str(base64.b64encode(
                self.credentials.encode("utf-8")), "utf-8")
            headers['Authorization'] = "Basic {}".format(basic_auth)
        elif self.auth_token:
            headers["Authorization"] = "Bearer {}".format(self.auth_token)
        return headers

    def load_config(self):
        """
        Loads the server configuration
        """
        url = "{}/config/{}/{}".format(self.server_url, self.application,
            self.profile)
        logger.info("Loading config from %s", url)
        resp = requests.request('get', url, headers=self._make_headers())
        if not resp.ok:
            raise ServiceError(resp.status_code, resp.text)
        self.config = resp.json()
        self.config_fields = self.config['propertySources'][0]['source']
        logger.info("Loaded configuration: %s", str(self.config))
        logger.info("Using fields: %s", str(self.config_fields))

    def load_and_set_to_flask_app(self, flask_app):
        """
        Loads the server configuration and appends all fields to
        an flask_app.config object
        """
        self.load_config()
        for k,v in self.config_fields.items():
            flask_app.config[k] = v

    def __getitem__(self, key):
        if not self.config_fields:
            self.load_config()
        return self.config_fields.get(key, None)

class EurekaClient:
    """
    EurekaClient is used to register an application on an Eureka server.
    This class manages connecting to the server, registering the application,
    sending periodic heartbeat and other tasks.

    :param eureka_url: url to the Eureka server
    :param app_name: app name to be registered on the eureka server
    :param host_name: host_name to be advertised by the eureka server
    :param port: port to be advertised by the eureka server
    :param app_protocol: protocol (http or https) to be advertised
    :param instance_id: unique id of this instance of app_name (if not
                        provided, a random unique id is generated)
    :param heartbeat_interval: interval for the heartbeat messages in seconds
    :param credentials: credential tuple for the Eureka server, such as
                        ("admin","admin")
    :param auth_token: Bearer token if credentials are not provided
    :param home_url: home url of the application (defaults to base host_name)
    :param status_url: url for Eureka to use to check application status
                       (defaults to [host_name]/healthcheck)
    :param healthcheck_url: url for Eureka to use to check application status
                            (defaults to [host_name]/healthcheck)
    """
    def __init__(self,
                 eureka_url,
                 app_name,
                 host_name,
                 port,
                 app_protocol="http",
                 instance_id=None,
                 heartbeat_interval=30,
                 credentials=(),
                 auth_token=None,
                 home_url=None,
                 status_url=None,
                 healthcheck_url=None,
                 metadata=None):
        self.eureka_url = eureka_url
        ipaddr = socket.gethostbyname(host_name)
        if not instance_id:
            instance_id = "{}:{}".format(app_name, str(uuid.uuid1()))
        if not home_url:
            home_url = "{}://{}:{}/".format(app_protocol, host_name, port)
        if not status_url:
            status_url = "{}://{}:{}/healthcheck".format(app_protocol,
                host_name, port)
        if not healthcheck_url:
            healthcheck_url = "{}://{}:{}/healthcheck".format(app_protocol,
                host_name, port)
        default_instance =  {
            'instance': {
                'app': app_name,
                'instanceId': instance_id,
                'hostName': host_name,
                'ipAddr': ipaddr,
                'healthCheckUrl': healthcheck_url,
                'statusPageUrl': status_url,
                'homePageUrl': home_url,
                'status': 'UP',
                'port': {
                    '$': port,
                    '@enabled': 'true',
                },
                'vipAddress': app_name,
                'secureVipAddress': app_name,
                'metadata': metadata,
                'dataCenterInfo': {
                    '@class': 'com.netflix.appinfo.InstanceInfo$DefaultDataCenterInfo',
                    'name': 'MyOwn',
                },
            },
        }
        self.instance_info = default_instance
        self.app_name = self.instance_info['instance']['app']
        self.host_name = self.instance_info['instance']['hostName']
        self.instance_id = self.instance_info['instance']['instanceId']
        self.port = self.instance_info['instance']['port']['$']
        self.credentials = ":".join(list(credentials))
        self.auth_token = auth_token
        self.app_url = "{}/apps/{}".format(self.eureka_url, self.app_name)
        self.app_instance_url = "{}/{}".format(self.app_url, self.instance_id)
        self.heartbeat_task = None
        self.heartbeat_interval = heartbeat_interval
        self.terminate_thread = False
        logger.info("Creating client with instance definition %s",
            str(self.instance_info))

    def _make_headers(self, is_get=False):
        headers = {}
        if is_get:
            headers['accept'] = 'application/json'
        else:
            headers['content-type'] = 'application/json'
        if self.credentials:
            basic_auth = str(base64.b64encode(
                self.credentials.encode("utf-8")), "utf-8")
            headers['Authorization'] = "Basic {}".format(basic_auth)
        elif self.auth_token:
            headers["Authorization"] = "Bearer {}".format(self.auth_token)
        return headers

    def _handle_errors(self, response):
        if response.ok:
            logger.info("Response OK: %d", response.status_code)
            return
        logger.error("Error in response %d:\n%s", response.status_code,
                     response.text)
        raise EurekaClientError(response.status_code, response.text)

    def register(self, num_of_tries=3, interval=3):
        """
        Registers this instance on Eureka server.

        :param num_of_tries: how may times to try before giving up with an
                             exception
        :param interval: interval between tries in seconds
        """
        logger.info("Registering on %s with payload %s",
            self.eureka_url, str(self.instance_info))
        count = 0
        while count < num_of_tries or num_of_tries < 0:
            try:
                r = requests.post(self.app_url,
                    data=json.dumps(self.instance_info),
                    headers=self._make_headers())
                self._handle_errors(r)
                return
            except Exception as e:
                count += 1
                logger.error(("Error %d of %d while registering to Eureka "
                    "Server", count, num_of_tries))
                logger.error(e)
                logger.error("sleeping for %d", interval)
                if count >= num_of_tries:
                    raise e
                time.sleep(interval)

    def register_and_start_heartbeats(self, num_of_tries=3, interval=3):
        """
        Registers this instance and starts the heartbeat thread

        :param num_of_tries: how may times to try before giving up with an
                             exception
        :param interval: interval between tries in seconds
        """
        self.register(num_of_tries, interval)
        self.terminate_thread = False
        self.heartbeat_task = Thread(target=self._heartbeat)
        self.heartbeat_task.daemon = True
        self.heartbeat_task.start()

    def deregister(self):
        """
        De-registers this instance from the eureka server
        """
        logger.info("Deregistering from %s", self.app_instance_url)
        r = requests.request('delete', self.app_instance_url,
            headers=self._make_headers())
        self._handle_errors(r)

    def deregister_and_stop_heartbeats(self):
        """
        De-registers this instance and stops heartbeat thread
        """
        self.deregister()
        logger.info('Waiting heartbeat thread to finish...')
        self.terminate_thread = True
        self.heartbeat_task.join()
        logger.info('Heartbeat thread finished.')

    def _heartbeat(self, internal_sleep=3):
        while True:
            sleep_time = int(self.heartbeat_interval / internal_sleep)
            try:
                for i in range(sleep_time):
                    time.sleep(internal_sleep)
                    if self.terminate_thread:
                        logger.info("Terminating heartbeat thread (%d)", i)
                        return
                self.heartbeat()
            except Exception as ex:
                logger.error("Exception on heartbeat")
                logger.error(ex)

    def heartbeat(self):
        r = requests.put(self.app_instance_url, params={
            'status': 'UP',
            'lastDirtyTimestamp': str(get_timestamp()),
        }, headers=self._make_headers())
        self._handle_errors(r)

    def query(self, app=None, instance=None):
        request_url = "{}/apps/".format(self.eureka_url)
        if app is not None:
            request_url += app
            if instance is not None:
                request_url += '/' + instance
        elif instance is not None:
            request_url = "{}/instances/{}".format(self.eureka_url, instance)
        r = requests.get(request_url, headers=self._make_headers(is_get=True))
        self._handle_errors(r)
        return r.json()

    def query_vip(self, vip):
        request_url =  "{}/vips/{}".format(self.eureka_url, vip)
        r = requests.get(request_url, headers=self._make_headers(is_get=True))
        self._handle_errors(r)
        return r.json()

    def query_svip(self, svip):
        request_url =  "{}/svips/{}".format(self.eureka_url, svip)
        r = requests.get(request_url, headers=self._make_headers(is_get=True))
        self._handle_errors(r)
        return r.json()

    def update_status(self, status):
        r = requests.put("{}/status".format(self.app_instance_url),
            params={'value': status}, headers=self._make_headers())
        self._handle_errors(r)

    def update_meta(self, key, value):
        r = requests.put("{}/metadata".format(self.app_instance_url),
            params={key: value}, headers=self._make_headers())
        self._handle_errors(r)

class EurekaApp:
    """
    This class is used to access an App registered on an Eureka server,
    and invoking REST services on the registered instances of the application.
    Currently only a simple random selection of the instances is supported for
    load balancing.

    :param app_name: name of the application
    :param eureka_url: url to the eureka server
    :param eureka_credentials: credential tuple for the server such as
                               ("admin","admin")
    :param eureka_auth_token: bearer token if credentials are not provided
    :param use_ip: if should use ip to build the service url
    :param use_https: if should use https to build the service url
    """
    def __init__(self,
                 app_name,
                 eureka_url,
                 eureka_credentials=(),
                 eureka_auth_token=None,
                 use_ip=False,
                 use_https=True):
        self.app_name = app_name
        self.eureka_url = eureka_url
        self.eureka_credentials = ":".join(list(eureka_credentials))
        self.eureka_auth_token = eureka_auth_token
        self.use_ip = use_ip
        self.use_https = use_https
        self.instances = None
        self.last_load_instances = None
        self.service_auth_token = None

    def set_service_token(self, service_auth_token):
        self.service_auth_token = service_auth_token

    def authenticate(self, credentials):
        self.service_auth_token = None
        username, password = credentials
        data = {
            'username': username,
            'password': password,
            'rememberMe': True}
        resp = self.post('api/authenticate', json=data)
        self._handle_errors(resp)
        self.service_auth_token = resp.json()['id_token']

    def _load_instances(self):
        request_url =  "{}/apps/{}".format(self.eureka_url, self.app_name)
        logger.info("Loading instances for app %s from %s",
            self.app_name, request_url)
        r = requests.request('get', request_url, headers=self._make_eureka_headers())
        self._handle_errors(r)
        app_def = r.json()['application']
        self.instances = []
        for instance in app_def['instance']:
            instance['url'] = self._make_service_url(instance,
                self.use_ip, self.use_https)
            logger.info("Received instance %s with url %s",
                instance['instanceId'], instance['url'])
            logger.info(instance)
            self.instances.append(instance)

    def _safe_get(self, d, path):
        flds = path.split(".")
        value = d
        for f in flds:
            value = value.get(f, None)
            if not value:
                break
        return value

    def _make_service_url(self, instance, use_ip=False, use_https=True):
        host = instance['ipAddr']
        if not use_ip and instance.get('hostName'):
            host = instance['hostName']
        port = self._safe_get(instance, "port.$")
        port_enabled = str(self._safe_get(instance,
            "port.@enabled")).lower() == "true"
        secure_port = self._safe_get(instance, "securePort.$")
        secure_port_enabled = str(self._safe_get(instance,
            "securePort.@enabled")).lower() == "true"
        selected_port = port
        schema = "http"
        if (use_https and secure_port_enabled) or not port_enabled:
            selected_port = secure_port
            schema = "https"

        return "{}://{}:{}".format(schema, host, selected_port)

    def _handle_errors(self, response):
        if response.ok:
            logger.info("Response OK: %d", response.status_code)
            return
        logger.error("Error in response %d:\n%s", response.status_code, response.text)
        raise EurekaClientError(response.status_code, response.text)

    def _make_eureka_headers(self):
        headers = {'accept': 'application/json'}
        if self.eureka_credentials:
            basic_auth = str(base64.b64encode(
                self.eureka_credentials.encode("utf-8")), "utf-8")
            headers['Authorization'] = "Basic {}".format(basic_auth)
        elif self.eureka_auth_token:
            headers["Authorization"] = "Bearer {}".format(self.eureka_auth_token)
        return headers

    def _next_instance(self):
        if not self.instances:
            self._load_instances()
        up_instances = [x for x in self.instances if x['status'] == "UP"]
        if len(up_instances) == 0:
            logger.info("There are no instances UP for app %s",
                self.app_name)
            return None
        if len(up_instances) == 1:
            return self.instances[0]
        pos = random.randint(0, len(self.instances)-1)
        logger.info("Using instance %s for app %s",
            self.instances[pos]['instanceId'], self.app_name)
        return self.instances[pos]

    def request(self, method, service, **kwargs):
        """
        Makes a request to one of the instances of the application,
        folowing the requests library convention
        """
        if not self.instances:
            self._load_instances()
        if self.service_auth_token:
            headers = kwargs.get('headers', {})
            headers["Authorization"] = "Bearer {}".format(self.service_auth_token)
            kwargs['headers'] = headers
        inst_id = None
        url = None
        try:
            instance = self._next_instance()
            inst_id = instance['instanceId']
            sep = '/'
            if instance['url'].endswith('/') and service.startswith('/'):
                sep = ''
            url = "{}{}{}".format(instance['url'], sep, service)
            logger.info("Service %s making request to %s", self.app_name, url)
            response = requests.request(method, url, **kwargs)
            if not response.ok and response.status_code >= 500:
                raise ServiceError(response.status_code, response.text)
            return response
        except Exception as e:
            logger.info("Error in instance %s when requesting %s to %s",
                inst_id, method, url)
            if inst_id:
                instance['status'] = 'error'
            instance = self._next_instance()
            if not instance:
                self.instances = None
                raise e

    def get(self, service, params=None, **kwargs):
        """
        Makes a request to one of the instances of the application,
        folowing the requests library convention
        """
        return self.request('get', service, params=params, **kwargs)

    def options(self, service, **kwargs):
        """
        Makes a request to one of the instances of the application,
        folowing the requests library convention
        """
        return self.request('options', service, **kwargs)

    def head(self, service, **kwargs):
        """
        Makes a request to one of the instances of the application,
        folowing the requests library convention
        """
        return self.request('head', service, **kwargs)

    def post(self, service, data=None, json=None, **kwargs):
        """
        Makes a request to one of the instances of the application,
        folowing the requests library convention
        """
        return self.request('post', service, data=data, json=json, **kwargs)

    def put(self, service, data=None, **kwargs):
        """
        Makes a request to one of the instances of the application,
        folowing the requests library convention
        """
        return self.request('put', service, data=data, **kwargs)

    def patch(self, service, data=None, **kwargs):
        """
        Makes a request to one of the instances of the application,
        folowing the requests library convention
        """
        return self.request('patch', service, data=data, **kwargs)
    def delete(self, service, **kwargs):
        """
        Makes a request to one of the instances of the application,
        folowing the requests library convention
        """
        return self.request('delete', service, **kwargs)

class JHipsterRegistry:
    """
    JHipsterRegistry encapsulates the functionality of a JHipster Registry
    server. As such, supports a Spring Cloud Config server and an Eureka
    server.
    Check SpringCloudConfigServer and EurekaApp for details.

    :param url: url to the registry server
    :param credentials: credential tuple for the server such as
                        ("admin", "admin")
    :param auth_token: bearer token if credentials are not provided
    :param profile: Spring Cloud Config profile
    :param application: Spring Cloud Config application
    :param use_ip: if eureka app shoud use ip to build the service url
    :param use_https: if eureka app should use https to build the service url
    :param additional_config: additional config fields. Check
                              SpringCloudConfigServer and EurekaApp for
                              details.
    """
    def __init__(self,
                 url,
                 credentials=(),
                 auth_token=None,
                 profile="prod",
                 application="application",
                 use_ip=False,
                 use_https=True,
                 additional_config=None):
        self.url = self._strip_url(url)
        self.credentials = credentials
        self.auth_token = auth_token
        self.profile = profile
        self.application = application
        self.use_ip = use_ip
        self.use_https = use_https
        self.conf = additional_config
        if not self.conf:
            self.conf = dict()
        self.eureka_url = self.url + '/eureka'
        if self.conf.get('EUREKA_SERVICE_URL'):
            self.eureka_url = self._strip_url(self.conf['EUREKA_SERVICE_URL'])
        self.config_url = self.url
        if self.conf.get('CONFIG_SERVER_URL'):
            self.config_url = self._strip_url(self.conf['CONFIG_SERVER_URL'])
        self.service_token_payload = JWT_PAYLOAD.copy()
        if self.conf.get('SERVICES_DEFAULT_JWT_PAYLOAD'):
            self.service_token_payload = (
                self.conf['SERVICES_DEFAULT_JWT_PAYLOAD'].copy())

    def _strip_url(self, url):
        if url.strip().endswith('/'):
            return url.strip()[:-1]
        return url.strip()

    @_cache.cache('_configserver', expire=3600)
    def _get_config(self, server_url, appplication, profile,
                    credentials, auth_token):
        logger.info("Loading config server on %s", server_url)
        server = SpringCloudConfigServer(
            server_url=server_url,
            appplication=appplication,
            profile=profile,
            credentials=credentials,
            auth_token=auth_token)
        server.load_config()
        return server

    @_cache.cache('_eurekaapp', expire=3600)
    def _get_app(self, app_name, eureka_url, eureka_credentials,
                 eureka_auth_token, use_ip, use_https,
                 service_token_payload, jwt_secret):
        logger.info("Creating app %s", app_name)
        app = EurekaApp(app_name,
                       eureka_url,
                       eureka_credentials=eureka_credentials,
                       eureka_auth_token=eureka_auth_token,
                       use_ip=use_ip,
                       use_https=use_https)
        token_payload = service_token_payload.copy()
        exp = datetime.datetime.utcnow() + datetime.timedelta(hours=24)
        token_payload['exp'] = exp
        token = jwt.encode(token_payload, jwt_secret, algorithm=JWT_ALGORITHM)
        app.set_service_token(token.decode('utf-8'))
        return app

    def app(self, name):
        """
        Gets an EurekaApp

        :param name: name of the application
        """
        conf = self.config()
        jwt_secret = conf['jhipster.security.authentication.jwt.secret']
        return self._get_app(
            app_name=name,
            eureka_url=self.eureka_url,
            eureka_credentials=self.credentials,
            eureka_auth_token=self.auth_token,
            use_ip=self.use_ip,
            use_https=self.use_https,
            service_token_payload=self.service_token_payload,
            jwt_secret=jwt_secret)

    def config(self):
        """
        Gets a SpringCloudConfig
        """
        return self._get_config(
            server_url=self.config_url,
            appplication=self.application,
            profile=self.profile,
            credentials=self.credentials,
            auth_token=self.auth_token)

def jhipster_date(date):
    tmp = date.strftime('%Y-%m-%dT%H:%M:%S')
    #coisas que a gente faz pelo java...
    tmp += ".{}Z".format(int(round(date.microsecond/1000000, 3)*1000))
    return tmp